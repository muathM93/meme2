//
//  sentMemesCollectionVC.swift
//  memeMe1
//
//  Created by Muath Mohammed on 15/02/1441 AH.
//  Copyright © 1441 MuathMohammed. All rights reserved.
//

import UIKit

class sentMemesCollectionVC: UICollectionViewController{
    

    
    
  var memes: [Meme]! {
          let object = UIApplication.shared.delegate
          let appDelegate = object as! AppDelegate
          return appDelegate.memes
      }
      
      override func viewDidLoad()
      {
          super.viewDidLoad()


      }
      override func viewWillAppear(_ animated: Bool)
      {
          super.viewWillAppear(animated)
          collectionView?.reloadData()
      }
      
      override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
      {
          return memes.count
      }
      
      override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
      {
          let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "reusebleID", for: indexPath) as! collectionCellVC
          
          let meme = memes[indexPath.row]
          cell.collectionViewImage?.image = meme.memedImage
          
          return cell
      }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let instanceView = self.storyboard!.instantiateViewController(withIdentifier: "imageID") as! viewMemeVC
        instanceView.meme = memes[indexPath.row]
        self.navigationController!.pushViewController(instanceView, animated: true)
    }

}
