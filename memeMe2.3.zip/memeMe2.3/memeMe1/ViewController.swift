//
//  ViewController.swift
//  memeMe1
//
//  Created by Muath Mohammed on 01/02/1441 AH.
//  Copyright © 1441 MuathMohammed. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate,
UINavigationControllerDelegate,UITextFieldDelegate{
    
    @IBOutlet weak var imagePickerView  : UIImageView!
    
    @IBOutlet weak var topBar           : UIToolbar!
    @IBOutlet weak var bottomBar        : UIToolbar!
    
    @IBOutlet weak var add              : UIBarButtonItem!
    @IBOutlet weak var take             : UIBarButtonItem!
    
    @IBOutlet weak var topTextFiled     : UITextField!
    @IBOutlet weak var bottomTextFiled  : UITextField!
    var activeTextFiled                 : UITextField!
    
    @IBOutlet weak var share            : UIBarButtonItem!
    @IBOutlet weak var cancel           : UIBarButtonItem!
    
    let memeTextAttributes:[NSAttributedString.Key: Any] = [
        NSAttributedString.Key.strokeColor: UIColor.black,
        NSAttributedString.Key.foregroundColor: UIColor.white,
        NSAttributedString.Key.font: UIFont(name: "HelveticaNeue-CondensedBlack", size: 30)!,
        NSAttributedString.Key.strokeWidth: -3.6]

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
            topTextFiled.defaultTextAttributes      = memeTextAttributes
            bottomTextFiled.defaultTextAttributes   = memeTextAttributes
            
            self.textFieldSetUp(textField: topTextFiled, content: "TOP")
            self.textFieldSetUp(textField: bottomTextFiled, content: "BOTTOM")
            
            take.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
        }
        
        func textFieldSetUp(textField: UITextField, content: String) -> Void {
            textField.text = content
            textField.textAlignment = .center
            textField.delegate = self
        }
        
    
    @objc func keyboardWillShow(notification: NSNotification) {
        
        if let keyboardSize                     = (notification.userInfo?[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            if bottomTextFiled.isEditing {
                if self.view.frame.origin.y     == 0 {
                    self.view.frame.origin.y    -= keyboardSize.height
                }
            }
        }
    }

    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        activeTextFiled = textField
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == bottomTextFiled {
                bottomTextFiled.text = ""
        }
        if textField == topTextFiled {
            topTextFiled.text       = ""
        }
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == bottomTextFiled || textField == bottomTextFiled  {
            if bottomTextFiled.text?.isEmpty ?? false {
                bottomTextFiled.text = "BOTTOM"
            }
            if topTextFiled.text?.isEmpty ?? false {
                topTextFiled.text = "TOP"
            }
        }
    }
    @IBAction func pickAnImage(_ sender: Any) {
    
      self.imageSuorce(src:"photoLibrary")
    }
    
    @IBAction func takeAnImage(_ sender: Any) {
        
      
        self.imageSuorce(src:"camera")
    }
    public func imageSuorce(src: String)
    {
        let imagePicker             = UIImagePickerController()
        imagePicker.delegate        = self
        imagePicker.allowsEditing   = true
        if src == "camera"
        {
            imagePicker.sourceType  = .camera
        }
        else if src == "photoLibrary"
        {
            imagePicker.sourceType  = .photoLibrary
        }
        present(imagePicker, animated: true, completion: nil)

    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if let image = info[UIImagePickerController.InfoKey.editedImage] as? UIImage
        {
            imagePickerView.image = image
        }
        dismiss(animated: true, completion: nil)
    }
    
    func generateMemedImage() -> UIImage {
 
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        return memedImage
    }
    
    @IBAction func shareAction(_ sender: Any) {
        
        bottomBar.isHidden = true
        topBar.isHidden    = true
        
        let  memedImage = generateMemedImage()
        if let image = imagePickerView.image {
            let meme = Meme(topText: topTextFiled.text!, bottomText: bottomTextFiled.text!, originalImage:image, memedImage: memedImage)
                        
                    let object      = UIApplication.shared.delegate
                    let appDelegate = object as! AppDelegate
                    appDelegate.memes.append(meme)
      
            let activityViewController = UIActivityViewController(activityItems: [meme.memedImage], applicationActivities: nil)
            activityViewController.popoverPresentationController?.sourceView = self.view
            self.present(activityViewController,animated: true,completion: nil)
        }
        else {
            let alert = UIAlertController(title: "Please, pick an image first", message: nil, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
            self.present(alert, animated: true)
        }
        bottomBar.isHidden = false
        topBar.isHidden    = false
    }
    
    
    
 
    @IBAction func cancelAction(_ sender: Any) {
        
        self.dismiss(animated: true, completion: nil)
        imagePickerView.image = nil
        bottomTextFiled.text  = "BOTTOM"
        topTextFiled.text     = "TOP"
    }
}

struct Meme {
    var topText       : String
    var bottomText    : String
    var originalImage : UIImage
    var memedImage    : UIImage
}

