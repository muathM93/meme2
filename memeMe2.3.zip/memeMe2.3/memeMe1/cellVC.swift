//
//  cellVC.swift
//  memeMe1
//
//  Created by Muath Mohammed on 15/02/1441 AH.
//  Copyright © 1441 MuathMohammed. All rights reserved.
//

import UIKit

class cellVC: UITableViewCell{

    @IBOutlet weak var viewImage: UIImageView!
}
