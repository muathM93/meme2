//
//  viewMemeVC.swift
//  memeMe1
//
//  Created by Muath Mohammed on 16/02/1441 AH.
//  Copyright © 1441 MuathMohammed. All rights reserved.
//

import UIKit

class viewMemeVC: UIViewController{

    
    @IBOutlet weak var memesImage: UIImageView!
    
    var meme:Meme!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        memesImage.image = meme.memedImage
    }
}

