//
//  sentMemesTableVC.swift
//  memeMe1
//
//  Created by Muath Mohammed on 15/02/1441 AH.
//  Copyright © 1441 MuathMohammed. All rights reserved.
//

import UIKit

class sentMemesTableVC: UITableViewController{
    var memes: [Meme]! {
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        return appDelegate.memes
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
        
    }
    
    override func tableView(_ tableView: UITableView,numberOfRowsInSection section: Int) -> Int
    {
        return memes.count
    }

    override func tableView(_ tableView: UITableView,cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "reusebleID", for: indexPath) as! cellVC
        
        
        cell.viewImage.image = memes[indexPath.row].memedImage
 
        return cell
        
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let instanceView = self.storyboard!.instantiateViewController(withIdentifier: "imageID") as! viewMemeVC
               instanceView.meme = memes[indexPath.row]
               self.navigationController!.pushViewController(instanceView, animated: true)
    }

}

